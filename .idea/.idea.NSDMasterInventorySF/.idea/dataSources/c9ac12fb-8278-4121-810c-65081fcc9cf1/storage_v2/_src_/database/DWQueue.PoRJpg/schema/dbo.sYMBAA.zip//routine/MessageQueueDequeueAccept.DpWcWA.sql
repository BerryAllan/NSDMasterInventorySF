
CREATE PROCEDURE [dbo].[MessageQueueDequeueAccept]
	@QueueName nvarchar(255),
	@MessageId uniqueidentifier
AS
BEGIN
	--Delete selected messages to complete the dequeue operation.
	DELETE FROM MessageQueue 
	WHERE QueueName = @QueueName 
	AND	 MessageId = @MessageId;
END

go

