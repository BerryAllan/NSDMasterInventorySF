
/*
   MessageQueueUpdate is used by the rollback manager to update the state of the message queue.
   This occurs when a undo operation fails and the priority, body, or active state needs to be updated.
*/
CREATE PROCEDURE [dbo].[MessageQueueUpdate]
	@QueueName nvarchar(255),
	@MessageId uniqueidentifier,
	@DateActive datetime,
	@Priority int = NULL,
	@IsActive int = 1,
	@MessageBody varbinary(MAX)
AS
BEGIN
	--Update selected messages to be dequeued again.
	UPDATE MessageQueue WITH  (READCOMMITTED, READPAST)
	SET DateActive = @DateActive, 
		Priority = ISNULL(@Priority, Priority),
		MessageBody = ISNULL(@MessageBody, MessageBody),
		IsActive = ISNULL(@IsActive, IsActive)
	WHERE QueueName = @QueueName 
	AND	 MessageId = @MessageId;
END
go

