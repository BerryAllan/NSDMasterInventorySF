

CREATE PROCEDURE [dbo].[MessageQueuePeek]
	@QueueName nvarchar(255),
	@BatchSize int = 1,
	@DateActive datetime = NULL,
	@CorrelationId uniqueidentifier = NULL,
	@LookupField1 nvarchar(255) = NULL,
	@LookupField2 nvarchar(255) = NULL,
	@LookupField3 nvarchar(255) = NULL,
	@IsActive int = 1
AS
BEGIN
	SELECT TOP(@BatchSize) *
	FROM MessageQueue WITH (NOLOCK)
	WHERE QueueName = @QueueName
		AND (@IsActive IS NULL OR IsActive = @IsActive)
		AND DateActive <= @DateActive
		AND (@LookupField1 IS NULL OR LookupField1 LIKE @LookupField1)
		AND (@LookupField2 IS NULL OR LookupField2 LIKE @LookupField2)
		AND (@LookupField3 IS NULL OR LookupField3 LIKE @LookupField3)
	ORDER BY Priority ASC, DateActive ASC, [Sequence] ASC
END

go

