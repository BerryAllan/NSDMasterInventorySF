
CREATE PROCEDURE [dbo].[TransactionStateDelete]
	@OperationId uniqueidentifier
AS
BEGIN
	DELETE FROM TransactionState
	WHERE OperationId = @OperationId;
END

go

