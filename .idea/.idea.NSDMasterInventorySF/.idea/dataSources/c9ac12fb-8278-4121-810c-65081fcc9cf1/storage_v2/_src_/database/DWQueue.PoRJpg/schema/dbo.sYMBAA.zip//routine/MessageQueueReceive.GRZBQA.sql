CREATE PROCEDURE [dbo].[MessageQueueReceive]
	        @QueueName nvarchar(255),
	        @DateActive datetime = NULL,
	        @IsActive int = 1
        AS
        BEGIN
	        --select a batch of messages based on priority and activation date
	        --messages are selected with priority 0 being the highest and only
	        --if activation date is at @DateActive or before that.

	        SELECT TOP(1) mq1.*
	        FROM MessageQueue mq1 WITH (READCOMMITTED, READPAST, FORCESEEK INDEX(IX_ActiveMessages))
	        WHERE
		        mq1.MessageId NOT IN
		        (
			        SELECT ts1.OperationId
			        FROM TransactionState ts1
			        LEFT JOIN TransactionState ts2 WITH (READCOMMITTED, READPAST) ON ts1.OperationId = ts2.OperationId
			        WHERE ts2.OperationId is null
		        )
	        AND QueueName = @QueueName
	        AND (@IsActive IS NULL OR IsActive = @IsActive)
	        AND (@DateActive IS NULL OR DateActive <= @DateActive)
	        AND Priority >= 0
            --Below ORDER BY removed as it not necessary due to IX_ActiveMessages index.  Including the
            --ORDER BY below could cause the optimizer to generate a plan that will sort and spill to tempdb
            --which is undesirable due to the performance implications.  See vsts# 2013514 for details.
	        --ORDER BY Priority ASC, DateActive ASC, [Sequence] ASC
	        option ( fast 1 )
        END
go

