
CREATE PROCEDURE [dbo].[MessageQueueDeleteMessage]
	@QueueName nvarchar(255),
	@MessageId uniqueidentifier
AS
BEGIN
	DELETE FROM MessageQueue 
	WHERE MessageId = @MessageId AND QueueName = @QueueName;
END
go

