
CREATE PROCEDURE [dbo].[TransactionStateGetCommittedOperationState]
	@OperationId uniqueidentifier
AS
BEGIN
	SELECT [State] FROM TransactionState WITH (READCOMMITTED,READPAST)
	WHERE OperationId = @OperationId;
END

go

