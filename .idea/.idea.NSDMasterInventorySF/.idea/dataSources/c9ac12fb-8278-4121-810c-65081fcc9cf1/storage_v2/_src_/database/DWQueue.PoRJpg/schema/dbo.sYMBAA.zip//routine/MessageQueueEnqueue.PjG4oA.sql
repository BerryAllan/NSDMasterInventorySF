
CREATE PROCEDURE [dbo].[MessageQueueEnqueue]
	@MessageId uniqueidentifier,
	@QueueName nvarchar(255),
	@DateActive datetime,
	@IsActive bit,
	@Priority int,
	@MessageBody varbinary(MAX),
	@CorrelationId uniqueidentifier = NULL,
	@LookupField1 nvarchar(255) = NULL,
	@LookupField2 nvarchar(255) = NULL,
	@LookupField3 nvarchar(255) = NULL
AS
BEGIN
	
	INSERT INTO MessageQueue(MessageId, 
		QueueName, 
		DateActive, 
		IsActive,
		Priority, 
		MessageBody, 
		CorrelationId,
		LookupField1,
		LookupField2,
		LookupField3,
		DateCreated)
	VALUES (@MessageId, 
		@QueueName, 
		@DateActive, 
		@IsActive,
		@Priority, 
		@MessageBody, 
		@CorrelationId,
		@LookupField1,
		@LookupField2,
		@LookupField3,
		GetDate());
END

go

