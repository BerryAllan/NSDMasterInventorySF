
CREATE PROCEDURE [dbo].[MessageQueueActivate]
	@QueueName nvarchar(255),
	@MessageId uniqueidentifier
AS
BEGIN
	--Delete selected messages to complete the dequeue operation.
	UPDATE MessageQueue  WITH (READCOMMITTED, READPAST)
	SET IsActive = 1
	WHERE QueueName = @QueueName 
	AND	MessageId = @MessageId
END

go

