
CREATE PROCEDURE [dbo].[UpgradeDWQueue]
	-- Parameters
	@StoredVer INT, -- Currently stored version in the version_history table
	@DatabaseName NVARCHAR(MAX) -- Name of the Database to modify.  It is important to keep this generic to accommodate both setup and Backup/Restore
	AS
	BEGIN
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;

		-- Constants

		-- Work Variables
		DECLARE @ErrorMessage NVARCHAR(MAX);
		DECLARE @Sql NVARCHAR(MAX);

		------------------------------------------------------------------------------------------
		-- Validate All Input Parameters
		------------------------------------------------------------------------------------------

		-- Make sure the database exists.
		PRINT N'Database name is: ' + @DatabaseName;

		if DB_ID(@DatabaseName) IS NULL
		BEGIN
			SET @ErrorMessage = N'ERROR: Database "' + @DatabaseName + N'" does not exist.'
			raiserror(@ErrorMessage,16,1);
			return -1;
		END

		-- IMPORTANT!!! Specify the changes required for execution during Madison upgrade.
		-- For every NON-rerunnable change that is added, the @CurrentScriptVer value
		-- needs to match the version number specified in the condition below.
	    -- This will guarantee that the change is only executed once.
		--
		-- For example, if making a change after version 1 is released, roll @CurrentScriptVer = 2 and
		-- ADD another IF block, "IF (@StoredVer < 2) BEGIN ... statements ... END"
		-- On error, use raiserror to return the error back to the caller.
		IF (@StoredVer < 1)
		BEGIN
			-- Specify NON-rerunnable changes here; i.e. the changes that should be executed only once,
			-- when this particular version of the script is executed
			-- or when a fresh install is being executed
			PRINT N'Current Version:' + CAST(@StoredVer AS nvarchar(10))

		END

		IF (@StoredVer < 61)
		BEGIN
			--Cleanup leaked records.  This will clean up records due to vsts 903400.  There should always be a MessageQueue record
			--if a record exists in TransactionState.
			DELETE FROM DWQueue.dbo.TransactionState where OperationId NOT IN ( SELECT MessageId from DWQueue.dbo.MessageQueue );

			--Prepare the TransactionState table for the new one state per operation model
			DELETE ts FROM DWQueue.dbo.TransactionState as ts
			WHERE [State] < (SELECT MAX([State])
				FROM DWQueue.dbo.TransactionState WHERE [OperationId] = ts.OperationId AND [TransactionId] = ts.TransactionId )

			--Remove the RollbackExecuted messages.  We no longer use this state, and since a state of 4 means that the
			--rollback operation has been executed, we do not need to invoke it.
			DELETE FROM DWQueue.dbo.MessageQueue WHERE [MessageId] IN ( SELECT [OperationId] FROM [dbo].[TransactionState] WHERE [State] = 4 );
			DELETE FROM DWQueue.dbo.TransactionState where State = 4;

			--Optimistically re-enable de-activated rollback messages.  These messages where likely de-activate due to rollover timeout,
			--and will likely complete on re-activation.
			UPDATE DWQueue.dbo.MessageQueue SET IsActive = 1 where IsActive = 0;

			--Not needed: DROP INDEX [IX_TransactionState_OperationId] on [dbo].[TransactionState];

			ALTER INDEX [PK_MessageQueue] ON [dbo].[MessageQueue] SET ( ALLOW_PAGE_LOCKS = OFF );
			ALTER INDEX [IX_MessageQueue_LookupField1] ON [dbo].[MessageQueue] SET ( ALLOW_PAGE_LOCKS = OFF );
			ALTER INDEX [IX_MessageQueue_LookupField2] ON [dbo].[MessageQueue] SET ( ALLOW_PAGE_LOCKS = OFF );
			ALTER INDEX [IX_MessageQueue_LookupField3] ON [dbo].[MessageQueue] SET ( ALLOW_PAGE_LOCKS = OFF );

			CREATE UNIQUE INDEX [IX_ActiveMessages] on [dbo].[MessageQueue]
			(
				[QueueName] ASC,
				[DateActive] ASC,
				[IsActive] ASC,
				[Priority] ASC,
				[Sequence] ASC,
				[MessageId] ASC
			) WITH (STATISTICS_NORECOMPUTE  = ON, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = OFF) ON [PRIMARY];

			DROP INDEX [IX_TransactionState_OperationId] ON [dbo].[TransactionState]

			CREATE UNIQUE CLUSTERED INDEX [PK_TransactionState] ON [dbo].[TransactionState] ( [OperationId] ASC ) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = OFF) ON [PRIMARY]

			--Disable lock escalation
			ALTER TABLE [dbo].[MessageQueue] set ( LOCK_ESCALATION = disable )
			ALTER TABLE [dbo].[TransactionState] set ( LOCK_ESCALATION = disable )
		END

		-- Specify rerunnable changes here;
		-- these changes can be executed during every upgrade, not just once
	END

    IF (@StoredVer < 86)
    BEGIN
        DROP INDEX [IX_ActiveMessages] ON [dbo].[MessageQueue];

        -- Recreate the index based on the sorting criteria for dequeuing a request.
        CREATE UNIQUE NONCLUSTERED INDEX [IX_ActiveMessages] ON [dbo].[MessageQueue]
        (
	        [QueueName] ASC,
	        [IsActive] ASC,
	        [Priority] ASC,
	        [DateActive] ASC,
	        [Sequence] ASC,
	        [MessageId] ASC
        ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = ON, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = OFF) ON [PRIMARY];

        -- Remove the order by clause that is implicitly enforced by the above index.
        -- This is necessary, as the optimizer cannot create an optimal plan for a stored procedure with
        -- passed parameters.  It will choose a plan that will sort the table, and spill to tempdb, causing
        -- excessive IO to tempdb.
        EXEC sp_executesql N'ALTER PROCEDURE [dbo].[MessageQueueReceive]
	        @QueueName nvarchar(255),
	        @DateActive datetime = NULL,
	        @IsActive int = 1
        AS
        BEGIN
	        --select a batch of messages based on priority and activation date
	        --messages are selected with priority 0 being the highest and only
	        --if activation date is at @DateActive or before that.

	        SELECT TOP(1) mq1.*
	        FROM MessageQueue mq1 WITH (READCOMMITTED, READPAST, FORCESEEK INDEX(IX_ActiveMessages))
	        WHERE
		        mq1.MessageId NOT IN
		        (
			        SELECT ts1.OperationId
			        FROM TransactionState ts1
			        LEFT JOIN TransactionState ts2 WITH (READCOMMITTED, READPAST) ON ts1.OperationId = ts2.OperationId
			        WHERE ts2.OperationId is null
		        )
	        AND QueueName = @QueueName
	        AND (@IsActive IS NULL OR IsActive = @IsActive)
	        AND (@DateActive IS NULL OR DateActive <= @DateActive)
	        AND Priority >= 0
            --Below ORDER BY removed as it not necessary due to IX_ActiveMessages index.  Including the
            --ORDER BY below could cause the optimizer to generate a plan that will sort and spill to tempdb
            --which is undesirable due to the performance implications.  See vsts# 2013514 for details.
	        --ORDER BY Priority ASC, DateActive ASC, [Sequence] ASC
	        option ( fast 1 )
        END'
    END
go

