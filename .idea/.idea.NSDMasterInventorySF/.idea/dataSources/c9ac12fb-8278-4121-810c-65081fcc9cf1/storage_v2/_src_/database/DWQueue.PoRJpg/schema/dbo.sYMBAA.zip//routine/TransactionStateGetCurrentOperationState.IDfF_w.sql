
CREATE PROCEDURE [dbo].[TransactionStateGetCurrentOperationState]
	@OperationId uniqueidentifier
AS
BEGIN
	SELECT [State] FROM TransactionState with (READUNCOMMITTED)
	WHERE OperationId = @OperationId;
END

go

