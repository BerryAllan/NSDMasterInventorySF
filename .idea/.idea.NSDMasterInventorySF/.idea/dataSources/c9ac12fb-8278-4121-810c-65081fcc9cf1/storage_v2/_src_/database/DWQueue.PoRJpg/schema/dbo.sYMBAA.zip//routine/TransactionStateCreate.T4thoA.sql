
/*
	TransactionStateCreate creates a transactional record in the transaction state table.
	The state of the transaction is then maintained by TransactionStateUpdate.
*/
CREATE PROCEDURE [dbo].[TransactionStateCreate]
	@TransactionId uniqueidentifier,
	@OperationId uniqueidentifier,
	@State int
AS
BEGIN
	INSERT INTO TransactionState (TransactionId, OperationId, State, DateCreated)
	VALUES(@TransactionId, @OperationId, @State, GetDate())
END
go

