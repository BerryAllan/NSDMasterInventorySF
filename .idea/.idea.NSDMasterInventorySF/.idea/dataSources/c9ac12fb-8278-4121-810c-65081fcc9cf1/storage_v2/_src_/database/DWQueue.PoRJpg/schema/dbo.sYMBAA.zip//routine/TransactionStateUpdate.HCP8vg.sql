
/*
	TransactionStateUpdate maintains the state of the transactional operation.  The state
	is initially created by TransactionStateCreate.
*/
CREATE PROCEDURE [dbo].[TransactionStateUpdate]
	@TransactionId uniqueidentifier,
	@OperationId uniqueidentifier,
	@State int
AS
BEGIN
	UPDATE TransactionState 
	SET [State] = @State
	WHERE [OperationId] = @OperationId
END
go

